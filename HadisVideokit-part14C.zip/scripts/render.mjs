// Part 14B: আসল রেন্ডার স্ক্রিপ্ট (Part 3-এর স্টাব এটাই বদলে দিল)। render.yml আগের মতোই এটাকে ডাকে — বদলাতে হয় না।
//
//   node scripts/render.mjs --id 0101 --book "সহীহ বুখারী" --number ১ \
//     --theme greenDayNight --orientation both --quality hd
//
// ধাপ: আর্গুমেন্ট যাচাই + ইনপুট ফাইল পরীক্ষা (14A, কয়েক সেকেন্ডে) → (--dry-run হলে টেবিল ছেপে শেষ)
//      → বান্ডল একবার → প্রতিটা জব একটার পর একটা: selectComposition → renderMedia → ফাইল যাচাই।
// কোনো জব ব্যর্থ হলে exit code 1 (আগে শেষ হওয়া mp4 out/ এ থেকে যায়)।
import { bundle } from "@remotion/bundler";
import { ensureBrowser, renderMedia, selectComposition } from "@remotion/renderer";
import { appendFileSync, existsSync, mkdirSync, rmSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { buildPlan, checkInputs, formatDryRun, formatReport } from "./lib/renderPlan.mjs";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

/** রেন্ডার ফেল করলে "মেমরি কম" মনে হয় এমন বার্তার চিহ্ন */
const OOM_PATTERN =
  /out of memory|ENOMEM|heap|Target closed|Page crashed|SIGKILL|SIGABRT|killed|std::bad_alloc|Protocol error/i;

// ---------- ছোট হেল্পার ----------
const summaryLines = [];
function say(line = "") {
  console.log(line);
}
/** টার্মিনালে ও (থাকলে) GitHub Step Summary-তে — Markdown */
function sayMd(line = "") {
  console.log(line);
  summaryLines.push(line);
}
function flushSummary() {
  if (process.env.GITHUB_STEP_SUMMARY && summaryLines.length > 0) {
    try {
      appendFileSync(process.env.GITHUB_STEP_SUMMARY, summaryLines.join("\n") + "\n");
    } catch {
      /* summary না লেখা গেলে রেন্ডার থামাই না */
    }
  }
}

function fmtDuration(ms) {
  const total = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}ঘ ${m}মি ${s}সে`;
  if (m > 0) return `${m}মি ${s}সে`;
  return `${s}সে`;
}

function fmtSize(bytes) {
  if (bytes >= 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

/** --frames দিয়ে টেস্ট রেন্ডার হলে নামের শেষে _test (আসল ফাইলের সাথে মিশবে না) */
function outputPathFor(job) {
  const file = job.frameRange ? job.outputFile.replace(/\.mp4$/i, "_test.mp4") : job.outputFile;
  return resolve(file);
}

/** [HADIS_DATA] এরর → বাংলা ব্যাখ্যা */
function explainHadisData(message) {
  const detail = message.split("[HADIS_DATA]").pop().trim();
  return [
    "হাদিসের ডেটা ফাইল পাওয়া যায়নি বা ঠিক নেই।",
    `কারণ: ${detail}`,
    "করণীয়: public/hadis/ ফোল্ডারে hadis<id>.wav ও hadis<id>_timestamp.json ঠিক নামে আছে কিনা এবং JSON-এর গঠন ঠিক কিনা দেখো (AI-কে আবার JSON বানাতে বলা যায়)।",
  ].join("\n   ");
}

function explainFailure(err) {
  const message = String(err?.message ?? err);
  if (message.includes("[HADIS_DATA]")) return { text: explainHadisData(message), hadisData: true };
  if (OOM_PATTERN.test(message)) {
    return {
      text: [
        `রেন্ডার মাঝপথে থেমে গেছে (সম্ভবত মেমরি কম): ${message.split("\n")[0]}`,
        "করণীয়: quality = hd দিয়ে চালাও, অথবা `--concurrency` কমাও (যেমন 2 বা 1)। 4K ও greenDayNight থিম বেশি মেমরি নেয়।",
      ].join("\n   "),
      hadisData: false,
    };
  }
  return {
    text: `রেন্ডার ব্যর্থ: ${message.split("\n")[0]}`,
    hadisData: false,
    stack: err?.known ? undefined : err?.stack,
  };
}

/** আমাদের নিজের জানা ভুল (stack দেখানোর দরকার নেই) */
function knownError(message) {
  const e = new Error(message);
  e.known = true;
  return e;
}

// ---------- একটা জব ----------
async function runJob({ job, total, serveUrl }) {
  const startedAt = Date.now();
  const outputLocation = outputPathFor(job);
  mkdirSync(dirname(outputLocation), { recursive: true });

  say(`\n▶ জব ${job.index}/${total}: ${job.label} → ${job.outputFile}`);

  // ১. কম্পোজিশন বেছে নেওয়া — মোট ফ্রেম ও সাইজ এখান থেকেই আসে (calculateMetadata)
  const composition = await selectComposition({
    serveUrl,
    id: job.compositionId,
    inputProps: job.inputProps,
  });

  const lastFrame = composition.durationInFrames - 1;
  let frameRange = null;
  if (job.frameRange) {
    const [start, end] = job.frameRange;
    if (start > lastFrame) {
      throw knownError(
        `--frames ${start}-${end} ঠিক নয়: ভিডিওতে মোট ${composition.durationInFrames}টা ফ্রেম (0 থেকে ${lastFrame})।`,
      );
    }
    const clampedEnd = Math.min(end, lastFrame);
    if (clampedEnd !== end) {
      say(`⚠️ শেষ ফ্রেম ${end} ভিডিওর বাইরে — ${clampedEnd} ধরা হলো।`);
    }
    frameRange = [start, clampedEnd];
  }
  const framesToRender = frameRange
    ? frameRange[1] - frameRange[0] + 1
    : composition.durationInFrames;
  const videoSeconds = framesToRender / composition.fps;

  // ফ্রেমের চেয়ে বেশি concurrency দিলে Remotion আপত্তি করে — তাই ছোট করে নিই
  const concurrency = Math.max(1, Math.min(job.concurrency, framesToRender));

  say(
    `   ${composition.width * job.scale}x${composition.height * job.scale} | ${framesToRender} ফ্রেম (${videoSeconds.toFixed(1)}সে) | concurrency ${concurrency} | crf ${job.crf}`,
  );

  // ২. রেন্ডার — প্রতি ~১০% এ এক লাইন
  let lastDecile = -1;
  await renderMedia({
    serveUrl,
    composition,
    codec: "h264",
    outputLocation,
    inputProps: job.inputProps,
    scale: job.scale,
    crf: job.crf,
    concurrency,
    frameRange,
    overwrite: true,
    imageFormat: "jpeg",
    jpegQuality: 90,
    // ভারী SVG/ফন্ট লোডের জন্য বাড়তি সময় (ডিফল্ট ৩০ সেকেন্ড)
    timeoutInMilliseconds: 120000,
    chromiumOptions: { enableMultiProcessOnLinux: true },
    onProgress: ({ progress }) => {
      const decile = Math.min(10, Math.floor(progress * 10));
      if (decile > lastDecile) {
        lastDecile = decile;
        const elapsed = Date.now() - startedAt;
        const eta = progress > 0.02 ? (elapsed / progress) * (1 - progress) : NaN;
        say(
          `   [${job.index}/${total}] ${Math.round(progress * 100)}% | গত ${fmtDuration(elapsed)}${
            Number.isFinite(eta) ? ` | বাকি ~${fmtDuration(eta)}` : ""
          }`,
        );
      }
    },
  });

  // ৩. ফাইল যাচাই
  if (!existsSync(outputLocation)) {
    throw knownError(`রেন্ডার শেষ হলেও আউটপুট ফাইল তৈরি হয়নি: ${outputLocation}`);
  }
  const size = statSync(outputLocation).size;
  if (size === 0) {
    throw knownError(`আউটপুট ফাইল খালি (০ বাইট): ${outputLocation}`);
  }

  const renderMs = Date.now() - startedAt;
  say(`✅ জব ${job.index}/${total} শেষ: ${fmtSize(size)} | ${fmtDuration(renderMs)}`);
  return {
    file: job.frameRange ? job.outputFile.replace(/\.mp4$/i, "_test.mp4") : job.outputFile,
    label: job.label,
    size,
    videoSeconds,
    renderMs,
  };
}

// ---------- মূল ফ্লো ----------
async function main() {
  // ১. আর্গুমেন্ট যাচাই (ব্রাউজার ছাড়া)
  const result = buildPlan(process.argv.slice(2));
  if (result.warnings.length > 0) say(formatReport({ warnings: result.warnings }));
  if (!result.ok) {
    sayMd("## ❌ আর্গুমেন্টে ভুল\n");
    sayMd(formatReport({ errors: result.errors }));
    return 1;
  }
  const plan = result.plan;

  // ২. ইনপুট ফাইল আগেভাগে (কয়েক সেকেন্ডে ভুল ধরা পড়ে)
  const inputs = checkInputs(plan, projectRoot);
  const inputInfo = formatReport({ warnings: inputs.warnings, notes: inputs.notes });
  if (inputInfo) say(inputInfo);
  if (!inputs.ok) {
    sayMd("## ❌ দরকারি ফাইল পাওয়া যায়নি\n");
    sayMd(formatReport({ errors: inputs.errors }));
    return 1;
  }

  // ৩. --dry-run: টেবিল ছেপে শেষ, ব্রাউজার ছাড়া
  if (plan.dryRun) {
    sayMd("## 📋 রেন্ডার পরিকল্পনা (--dry-run, কিছু রেন্ডার হয়নি)\n");
    sayMd("```\n" + formatDryRun(plan) + "\n```");
    return 0;
  }

  const total = plan.jobs.length;
  say(`\nমোট ${total}টা জব রেন্ডার হবে (একটার পর একটা)।`);

  // ৪. ব্রাউজার + বান্ডল (একবারই)
  say("▶ ব্রাউজার যাচাই...");
  await ensureBrowser();

  say("▶ বান্ডল তৈরি হচ্ছে...");
  const serveUrl = await bundle({
    entryPoint: join(projectRoot, "src", "index.ts"),
    publicDir: join(projectRoot, "public"),
  });

  // ৫. জবগুলো একে একে
  const done = [];
  const failed = [];
  try {
    for (const job of plan.jobs) {
      try {
        done.push(await runJob({ job, total, serveUrl }));
      } catch (err) {
        const info = explainFailure(err);
        say(`\n❌ জব ${job.index}/${total} (${job.label}) ব্যর্থ:\n   ${info.text}`);
        if (info.stack && !info.hadisData) say(`\n${info.stack}`);
        failed.push({ label: job.label, reason: info.text.split("\n")[0] });
        // ডেটা ফাইলের সমস্যা সব জবেই একই — আর চেষ্টা করে লাভ নেই
        if (info.hadisData) break;
      }
    }
  } finally {
    try {
      rmSync(serveUrl, { recursive: true, force: true });
    } catch {
      /* বান্ডলের অস্থায়ী ফোল্ডার মোছা না গেলে সমস্যা নেই */
    }
  }

  // ৬. শেষের টেবিল
  sayMd(`\n## ${failed.length === 0 ? "✅" : "⚠️"} রেন্ডার শেষ — ${done.length}/${total} ভিডিও তৈরি\n`);
  if (done.length > 0) {
    sayMd("| ফাইল | সাইজ | ভিডিওর দৈর্ঘ্য | রেন্ডারে সময় |");
    sayMd("|---|---|---|---|");
    for (const d of done) {
      sayMd(
        `| \`${d.file}\` (${d.label}) | ${fmtSize(d.size)} | ${d.videoSeconds.toFixed(1)}সে | ${fmtDuration(d.renderMs)} |`,
      );
    }
  }
  if (failed.length > 0) {
    sayMd("\n### ❌ ব্যর্থ জব\n");
    for (const f of failed) sayMd(`- ${f.label}: ${f.reason}`);
    sayMd("\nআগে শেষ হওয়া ভিডিওগুলো `out/` এ আছে।");
    return 1;
  }
  return 0;
}

let exitCode = 1;
try {
  exitCode = await main();
} catch (err) {
  // অপ্রত্যাশিত ভুল (যেমন বান্ডল/ব্রাউজার চালু হয়নি): পুরো stack দেখাই, exit 1
  sayMd(`\n## ❌ রেন্ডার ব্যর্থ\n\n\`\`\`\n${err?.stack ?? err}\n\`\`\``);
  exitCode = 1;
} finally {
  flushSummary();
}
process.exit(exitCode);
